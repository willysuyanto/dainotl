<?php return array (
  'create-nozzle' => 'App\\Http\\Livewire\\CreateNozzle',
  'edit-supply' => 'App\\Http\\Livewire\\EditSupply',
  'stock-form' => 'App\\Http\\Livewire\\StockForm',
  'supply-item' => 'App\\Http\\Livewire\\SupplyItem',
);