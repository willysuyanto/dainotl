<div class="col-xs-12 col-sm-12 col-md-12">
    <div class="form-group">
        <strong>Jenis BBM </strong>
        <select name="product" id="select-product" class="input-group form-control">
            <option value="">Pilih Jenis BBM</option>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($product->id); ?>"><?php echo e($product->product_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
        <strong>Jenis BBM</strong>
        <select name="product" id="select-product" class="input-group form-control">
            <option value="">Pilih Jenis BBM</option>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($product->id); ?>"><?php echo e($product->product_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-2 my-4">
        <button wire:click.prevent="add" class="btn btn-primary btn-block">
            <span class="btn-label">
                <i class="fa fa-plus"></i>
            </span>
            Tambah Item
        </button>
    </div>
</div>
<?php /**PATH C:\Users\Lenovo\Project\Laravel\daino-tl-system\resources\views/livewire/create-nozzle.blade.php ENDPATH**/ ?>