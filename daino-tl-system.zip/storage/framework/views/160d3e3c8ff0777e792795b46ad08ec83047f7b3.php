

<?php $__env->startSection('title'); ?>
    <title>Daino TL System | Lihat Data Role</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h4 class="page-title">Lihat Data Role</h4>
    <ul class="breadcrumbs">
        <li class="nav-home">
            <a href="#">
                <i class="flaticon-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Administration</a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('roles.index')); ?>">Role Management</a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Lihat Data Role</a>
        </li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Lihat Data Role</h4>
        </div>
        <div class="card-body">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Nama Role</strong>
                    <p><?php echo e($role->name); ?></p>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Permissions:</strong>
                    <?php if(!empty($rolePermissions)): ?>
                        <?php $__currentLoopData = $rolePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->iteration == count($rolePermissions)): ?>
                            <label class="label label-success"><?php echo e($v->name); ?></label>
                            <?php else: ?>
                            <label class="label label-success"><?php echo e($v->name); ?>,</label>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-footer row justify-content-end">
                <div class="col-xs-12 col-sm-12 col-md-2">
                    <a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="btn btn-primary btn-block" >Edit Data</a>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-2">
                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-danger btn-block" >Kembali</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script >
    $(document).ready(function() {
        $('#role').select2({
			theme: "bootstrap"
            
		}).enable(false);
        <?php if(count($errors) > 0): ?>
            $.notify({
                icon: 'flaticon-error',
                title: 'Gagal Membuat Data',
                message: '<?php echo e($errors->first()); ?>',
            },
            {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "center"
                },
                time: 500,
                autoHideDelay: 1000,
            });
        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Project\Laravel\daino-tl-system\resources\views/roles/show.blade.php ENDPATH**/ ?>