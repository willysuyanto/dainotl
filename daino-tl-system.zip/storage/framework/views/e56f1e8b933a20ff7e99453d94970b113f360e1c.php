

<?php $__env->startSection('title'); ?>
    <title>Daino TL System | Detail Pemesanan BBM</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h4 class="page-title">Detail Pemesanan BBM</h4>
    <ul class="breadcrumbs">
        <li class="nav-home">
            <a href="#">
                <i class="flaticon-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Menu Utama</a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('roles.index')); ?>">Pemesanan BBM</a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Detail Pemesanan BBM</a>
        </li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Detail Pemesanan BBM</h4>
        </div>
        <div class="card-body">
            <div class="col-xs-12 col-sm-12 col-md-4">
                <div class="form-group">
                    <strong>Nomor SO</strong>
                    <p class=""><?php echo e($supply->so_number); ?></p>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4">
                <div class="form-group">
                    <strong>Nomor Referensi</strong>
                    <p><?php echo e($supply->ref_number); ?></p>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4">
                <div class="form-group">
                    <strong>Total Harga</strong>
                    <p><?php echo e(toRupiah($supply->total_debit_amount)); ?></p>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Item Pemesanan BBM</strong>
                    <?php if(!empty($supply->items)): ?>
                    <table id="basic-datatables" class="display table table-bordered table-hover" >
                        <thead>
                            <tr>
                                <th>Jenis BBM</th>
                                <th>Trip</th>
                                <th>Trip Terkirim</th>
                                <th>Quantity per Trip (L)</th>
                                <th>Total Quantity (L)</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Jenis BBM</th>
                                <th>Trip</th>
                                <th>Trip Terkirim</th>
                                <th>Quantity per Trip (L)</th>
                                <th>Total Quantity (L)</th>
                                <th>Status</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $supply->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->product->first()->product_name); ?></td>
                                <td><?php echo e($item->trip); ?></td>
                                <td><?php echo e($item->trip_delivered); ?></td>
                                <td><?php echo e($item->trip_quantity); ?></td>
                                <td><?php echo e($item->confirmed_quantity); ?></td>
                                <td><?php echo e($item->status); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="card-footer row justify-content-end">
            <div class="col-xs-12 col-sm-12 col-md-2 mx-2 mb-2">
                <a href="<?php echo e(route('supply.edit', $supply->id)); ?>" class="btn btn-primary btn-block" >Edit Data</a>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-2 mx-2">
                <a href="<?php echo e(route('supply.index')); ?>" class="btn btn-danger btn-block" >Kembali</a>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script >
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Project\Laravel\daino-tl-system\resources\views/supply/show.blade.php ENDPATH**/ ?>