

<?php $__env->startSection('title'); ?>
    <title>Daino TL System | Ubah Password</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h4 class="page-title">Ubah Password</h4>
    <ul class="breadcrumbs">
        <li class="nav-home">
            <a href="#">
                <i class="flaticon-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Ubah Password</a>
        </li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <?php echo Form::open(array('route' => 'password.update','method'=>'POST')); ?>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Password Lama</strong>
                    <?php echo Form::password('password', array('placeholder' => 'Password Lama','class' => 'form-control')); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Password Baru</strong>
                    <?php echo Form::password('new_password', array('placeholder' => 'Password Baru','class' => 'form-control')); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Konfirmasi Password Baru</strong>
                    <?php echo Form::password('confirm_new_password', array('placeholder' => 'Konfirmasi Password Baru','class' => 'form-control')); ?>

                </div>
            </div>
        </div>
        <div class="card-footer row justify-content-end">
            <div class="col-xs-12 col-sm-12 col-md-2 my-2 mb-2">
                <button class="btn btn-primary btn-block">Ubah Password</button>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-2 my-2 mx-2">
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-danger btn-block" >Batal</a>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script >
    $(document).ready(function() {
        <?php if(count($errors) > 0): ?>
            $.notify({
                icon: 'flaticon-error',
                title: 'Gagal Membuat Data',
                message: '<?php echo e($errors->first()); ?>',
            },
            {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "center"
                },
                time: 500,
                autoHideDelay: 1000,
            });
        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Project\Laravel\daino-tl-system\resources\views/auth/change-password.blade.php ENDPATH**/ ?>