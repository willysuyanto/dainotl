<?php $__env->startSection('title'); ?>
    <title>Daino TL System | Dashboard</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h4 class="page-title">Dashboard</h4>
    <ul class="breadcrumbs">
        <li class="nav-home">
            <a href="#">
                <i class="flaticon-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Dashboard</a>
        </li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    Halaman Dashboard User
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script >
     $(document).ready(function() {
        $('#basic-datatables').DataTable({
        });
        <?php if($message = Session::get('success')): ?>
            $.notify({
                icon: 'flaticon-alarm-1',
                title: 'Sukses',
                message: '<?php echo e($message); ?>',
            },
            {
                type: 'success',
                placement: {
                    from: "top",
                    align: "center"
                },
                time: 500,
                autoHideDelay: 1000,
            });
        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Project\Laravel\daino-tl-system\resources\views/dashboard.blade.php ENDPATH**/ ?>