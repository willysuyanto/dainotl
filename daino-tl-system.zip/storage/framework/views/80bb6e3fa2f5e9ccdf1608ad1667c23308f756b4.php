

<?php $__env->startSection('title'); ?>
    <title>Daino TL System | Tambah Nozzle</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h4 class="page-title">Tambah Nozzle</h4>
    <ul class="breadcrumbs">
        <li class="nav-home">
            <a href="#">
                <i class="flaticon-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Master Data</a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('nozzle.index')); ?>">Nozzle</a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Tambah Nozzle</a>
        </li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Form Tambah Nozzle</h4>
        </div>
        <div class="card-body">
            <?php echo Form::open(array('route' => 'nozzle.store','method'=>'POST', 'spellcheck'=>"false")); ?>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Group</strong>
                    <select name="group" id="select-group" class="input-group form-control">
                        <option value="">Pilih Group</option>
                        <option value="Group 1">Group 1</option>
                        <option value="Group 2">Group 2</option>
                        <option value="Group 3">Group 3</option>
                        <option value="Group 4">Group 4</option>
                        <option value="Group 5">Group 5</option>
                        <option value="Group 6">Group 6</option>
                        <option value="Group 7">Group 7</option>
                        <option value="Group 8">Group 8</option>
                    </select>
                </div>
            </div>                
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Jenis BBM</strong>
                    <select name="product" id="select-product" class="input-group form-control">
                        <option value="">Pilih Jenis BBM</option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->product_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Totalizer Terakhir</strong>
                    <?php echo Form::text('', null, array('placeholder' => 'Totalizer Terakhir', 'class' => 'form-control', 'id' => 'initialStock', 'onchange' => 'unmaskPurchase(value)')); ?>

                    <?php echo Form::hidden('last_totalizer', null, array('class' => 'form-control', 'id' => 'initial_stock')); ?>

                </div>
            </div>                
        </div>
        <div class="card-footer row justify-content-end">
            <div class="col-xs-12 col-sm-12 col-md-2 mx-2 mb-2">
                <button class="btn btn-primary btn-block">Simpan</button>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-2 mx-2">
                <a href="<?php echo e(URL::previous()); ?>" class="btn btn-danger btn-block" > Batal</a>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script >
     var maskOptions = {
        lazy: false,
        mask: Number,
        signed: false, 
        thousandsSeparator: '.', 
    }
    var element = document.getElementById('initialStock');

    var stockMask = IMask(element, maskOptions);
    function unmaskPurchase(){
        $('#initial_stock').val(stockMask.unmaskedValue);
    }

    $(document).ready(function() {

        $("#select-group").select2({
            placeholder: "Pilih Grup",
            theme: "bootstrap"
        });

        $("#select-product").select2({
            placeholder: "Pilih Jenis BBM",
            theme: "bootstrap"
        });

        <?php if(count($errors) > 0): ?>
            $.notify({
                icon: 'flaticon-error',
                title: 'Gagal Membuat Data',
                message: '<?php echo e($errors->first()); ?>',
            },
            {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "center"
                },
                time: 500,
                autoHideDelay: 1000,
            });
        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Project\Laravel\daino-tl-system\resources\views/nozzle/create.blade.php ENDPATH**/ ?>