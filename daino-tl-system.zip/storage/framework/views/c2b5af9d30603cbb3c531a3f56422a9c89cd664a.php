

<?php $__env->startSection('title'); ?>
    <title>Daino TL System | Detail Hutang Karyawan</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h4 class="page-title">Detail Hutang Karyawan</h4>
    <ul class="breadcrumbs">
        <li class="nav-home">
            <a href="#">
                <i class="flaticon-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Menu Utama</a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('employee.index')); ?>">Piutang Karyawan</a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Detail Hutang Karyawan</a>
        </li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Detail Hutang Karyawan</h4>
        </div>
        <div class="card-body">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Nama Lengkap</strong>
                    <p><?php echo e($employee->full_name); ?></p>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Nomor Karyawan</strong>
                    <p><?php echo e($employee->employee_number); ?></p>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Detail Hutang</strong>
                    <?php if(!empty($employee->loans)): ?>
                    <table id="basic-datatables" class="display table table-bordered table-hover" >
                        <thead>
                            <tr>
                                <th>Nominal</th>
                                <th>Jenis</th>
                                <th>Tanggal</th>
                                <th>Catatan</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Nominal</th>
                                <th>Jenis</th>
                                <th>Tanggal</th>
                                <th>Catatan</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $employee->loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>Rp.<?php echo e(number_format($item->nominal)); ?>,-</td>
                                <td><?php echo e($item->type == 'hutang'? "Hutang" : "Pembayaran"); ?></td>
                                <td><?php echo e(format($item->created_at, "d/m/Y")); ?></td>
                                <td><?php echo e($item->notes); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="card-footer row justify-content-end">
            <div class="col-xs-12 col-sm-12 col-md-2 mx-2">
                <a href="<?php echo e(route('employee-loan.index')); ?>" class="btn btn-danger btn-block" >Kembali</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script >
   
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Project\Laravel\daino-tl-system\resources\views/employee-loan/show.blade.php ENDPATH**/ ?>