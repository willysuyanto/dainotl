

<?php $__env->startSection('title'); ?>
    <title>Daino TL System | Detail Stok BBM</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h4 class="page-title">Detail Stok BBM</h4>
    <ul class="breadcrumbs">
        <li class="nav-home">
            <a href="#">
                <i class="flaticon-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Menu Utama</a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('roles.index')); ?>">Stok BBM</a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Detail Stok BBM</a>
        </li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
                <h4 class="card-title"><?php echo e($product->product_name); ?></h4>
        </div>
        <div class="card-body">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <table id="basic-datatables" class="display table table-bordered table-hover" >
                        <thead>
                            <tr>
                                <th>Jenis Stock</th>
                                <th>Quantity (L)</th>
                                <th>Nomor SO</th>
                                <th>Tanggal</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Jenis Stock</th>
                                <th>Quantity (L)</th>
                                <th>Nomor SO</th>
                                <th>Tanggal</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $product_stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php if($stock->stock_type == 'stock_in'): ?>
                                <td>Delivered</td>
                                <?php elseif($stock->stock_type == 'initial'): ?>
                                <td>Stok Awal</td>
                                <?php else: ?>
                                <td>Sold</td>
                                <?php endif; ?>
                                <td><?php echo e(number_format($stock->quantity, 1)); ?></td>
                                <td><?php echo e($stock->so_from); ?></td>
                                <td><?php echo e($stock->stock_date); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card-footer row justify-content-end">
            <div class="col-xs-12 col-sm-12 col-md-2 mx-2">
                <a href="<?php echo e(route('stock.index')); ?>" class="btn btn-danger btn-block" >Kembali</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script >
   $('#basic-datatables').DataTable({});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Project\Laravel\daino-tl-system\resources\views/stock/show.blade.php ENDPATH**/ ?>