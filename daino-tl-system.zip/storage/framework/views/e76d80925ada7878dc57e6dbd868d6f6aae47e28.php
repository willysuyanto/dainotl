

<?php $__env->startSection('title'); ?>
    <title>Daino TL System | Stok BBM Datang</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <div class="page-header">
        <h4 class="page-title">Stok BBM Datang</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="#">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Menu Utama</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('supply.index')); ?>">Stock BBM</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Stock BBM Datang</a>
            </li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Form BBM Datang</h4>
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('stock-form')->html();
} elseif ($_instance->childHasBeenRendered('mQSJkJ1')) {
    $componentId = $_instance->getRenderedChildComponentId('mQSJkJ1');
    $componentTag = $_instance->getRenderedChildComponentTagName('mQSJkJ1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mQSJkJ1');
} else {
    $response = \Livewire\Livewire::mount('stock-form');
    $html = $response->html();
    $_instance->logRenderedChild('mQSJkJ1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {

            <?php if(count($errors) > 0): ?>
                $.notify({
                icon: 'flaticon-error',
                title: 'Gagal Membuat Data',
                message: '<?php echo e($errors->first()); ?>',
                },
                {
                type: 'danger',
                placement: {
                from: "top",
                align: "center"
                },
                time: 500,
                autoHideDelay: 1000,
                });
            <?php endif; ?>

            window.initSelect2 = () => {
                $('#select-so').select2({
                    theme:'bootstrap',
                    placeholder: 'Pilih nomor SO'
                })

                $('#select-so1').select2({
                    theme:'bootstrap',
                    placeholder: 'Pilih item BBM datang'
                });
            }

            initSelect2();

            $('#select-so').on('change', (e)=>{
                livewire.emit('selected_so', e.target.value);
            });

            window.livewire.on('select2',()=>{
                initSelect2();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Project\Laravel\daino-tl-system\resources\views/stock/create.blade.php ENDPATH**/ ?>