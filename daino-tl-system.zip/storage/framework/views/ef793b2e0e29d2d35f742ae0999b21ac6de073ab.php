

<?php $__env->startSection('title'); ?>
    <title>Daino TL System | Penjualan BBM</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h4 class="page-title">Penjualan BBM</h4>
    <ul class="breadcrumbs">
        <li class="nav-home">
            <a href="/">
                <i class="flaticon-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Menu Utama</a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="#">Pemesanan BBM</a>
        </li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <ul class="nav nav-pills nav-secondary" id="pills-tab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="pills-shift1-tab" data-toggle="pill" href="#pills-shift1" role="tab" aria-controls="pills-shift1" aria-selected="true">Shift 1</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="pills-shift2-tab" data-toggle="pill" href="#pills-shift2" role="tab" aria-controls="pills-shift2" aria-selected="false">Shift 2</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="pills-shift3-tab" data-toggle="pill" href="#pills-shift3" role="tab" aria-controls="pills-shift3" aria-selected="false">Shift 3</a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content mt-2 mb-3" id="pills-tabContent">
                <div class="tab-pane fade show active" id="pills-shift1" role="tabpanel" aria-labelledby="pills-shift1-tab">
                    <div class="table-responsive">
                        <table id="basic-datatables" class="display table table-sm table-bordered table-hover" >
                            <thead>
                                <tr>
                                    <th>Nozzle</th>
                                    <th>Jenis BBM</th>
                                    <th>Totalizer Awal</th>
                                    <th>Totalizer Akhir</th>
                                    <th>Penjualan (L)</th>
                                    <th>Jumlah (Rp)</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Nozzle</th>
                                    <th>Jenis BBM</th>
                                    <th>Totalizer Awal</th>
                                    <th>Totalizer Akhir</th>
                                    <th>Penjualan (L)</th>
                                    <th>Jumlah (Rp)</th>
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $nozzles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $nozzle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="background-color: <?php echo e($nozzle->product->color); ?>;"><?php echo e($index + 1); ?></td>
                                    <td style="background-color: <?php echo e($nozzle->product->color); ?>;"><?php echo e($nozzle->product->product_name); ?></td>
                                    <td style="background-color: <?php echo e($nozzle->product->color); ?>;"><?php echo e($nozzle->todaySales('shift1')==null? number_format($nozzle->last_totalizer, 1) : $nozzle->todaySales('shift1')->first_totalizer); ?></td>
                                    <td style="background-color: <?php echo e($nozzle->product->color); ?>;"><?php echo e($nozzle->todaySales('shift1')==null? number_format($nozzle->last_totalizer, 1) : $nozzle->todaySales('shift1')->last_totalizer); ?></td>
                                    <td style="background-color: <?php echo e($nozzle->product->color); ?>;"><?php echo e(number_format($nozzle->salesDifference('shift1'),1)); ?></td>
                                    <td style="background-color: <?php echo e($nozzle->product->color); ?>;">Rp.<?php echo e(number_format($nozzle->salesDifference('shift1') * $nozzle->product->selling_price,1)); ?>,-</td>
                                    <td>
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('supply.details', $nozzle->id)); ?>">
                                                <button class="btn btn-info btn-xs mr-1">
                                                    <span class="btn-label">
                                                        <i class="fa icon-eye"></i>
                                                    </span>
                                                    Lihat
                                                </button>
                                            </a>
                                            <a href="<?php echo e(route('supply.edit', $nozzle->id)); ?>">
                                                <button class="btn btn-primary btn-xs mr-1">
                                                    <span class="btn-label">
                                                        <i class="fa icon-pencil"></i>
                                                    </span>
                                                    Edit
                                                </button>
                                            </a>
                                            <button onclick="return false" data-id="<?php echo e($nozzle->id); ?>" data-nama="<?php echo e($nozzle->id); ?>" class="confirmDelete btn btn-danger btn-xs">
                                                <span class="btn-label">
                                                    <i class="fa icon-trash"></i>
                                                </span>
                                                Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="tab-pane fade" id="pills-shift2" role="tabpanel" aria-labelledby="pills-shift2-tab">
                    <div class="table-responsive">
                        <table id="basic-datatables1" class="display table table-sm table-bordered table-hover" >
                            <thead>
                                <tr>
                                    <th>Nozzle</th>
                                    <th>Jenis BBM</th>
                                    <th>Totalizer Awal</th>
                                    <th>Totalizer Akhir</th>
                                    <th>Penjualan (L)</th>
                                    <th>Jumlah (Rp)</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Nozzle</th>
                                    <th>Jenis BBM</th>
                                    <th>Totalizer Awal</th>
                                    <th>Totalizer Akhir</th>
                                    <th>Penjualan (L)</th>
                                    <th>Jumlah (Rp)</th>
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $nozzles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $nozzle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($nozzle->product->product_name); ?></td>
                                    <td><?php echo e($nozzle->todaySales('shift1')==null? number_format($nozzle->last_totalizer, 1) : $nozzle->todaySales('shift1')->first_totalizer); ?></td>
                                    <td><?php echo e($nozzle->todaySales('shift1')==null? number_format($nozzle->last_totalizer, 1) : $nozzle->todaySales('shift1')->last_totalizer); ?></td>
                                    <td><?php echo e(number_format($nozzle->salesDifference('shift1'),1)); ?></td>
                                    <td>Rp.<?php echo e(number_format($nozzle->salesDifference('shift1') * $nozzle->product->selling_price,1)); ?>,-</td>
                                    <td>
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('supply.details', $nozzle->id)); ?>">
                                                <button class="btn btn-info btn-xs mr-1">
                                                    <span class="btn-label">
                                                        <i class="fa icon-eye"></i>
                                                    </span>
                                                    Lihat
                                                </button>
                                            </a>
                                            <a href="<?php echo e(route('supply.edit', $nozzle->id)); ?>">
                                                <button class="btn btn-primary btn-xs mr-1">
                                                    <span class="btn-label">
                                                        <i class="fa icon-pencil"></i>
                                                    </span>
                                                    Edit
                                                </button>
                                            </a>
                                            <button onclick="return false" data-id="<?php echo e($nozzle->id); ?>" data-nama="<?php echo e($nozzle->id); ?>" class="confirmDelete btn btn-danger btn-xs">
                                                <span class="btn-label">
                                                    <i class="fa icon-trash"></i>
                                                </span>
                                                Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="tab-pane fade" id="pills-shift3" role="tabpanel" aria-labelledby="pills-shift3-tab">
                    <div class="table-responsive">
                        <table id="basic-datatables2" class="display table table-sm table-bordered table-hover" >
                            <thead>
                                <tr>
                                    <th>Nozzle</th>
                                    <th>Jenis BBM</th>
                                    <th>Totalizer Awal</th>
                                    <th>Totalizer Akhir</th>
                                    <th>Penjualan (L)</th>
                                    <th>Jumlah (Rp)</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Nozzle</th>
                                    <th>Jenis BBM</th>
                                    <th>Totalizer Awal</th>
                                    <th>Totalizer Akhir</th>
                                    <th>Penjualan (L)</th>
                                    <th>Jumlah (Rp)</th>
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $nozzles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $nozzle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($nozzle->product->product_name); ?></td>
                                    <td><?php echo e($nozzle->todaySales('shift1')==null? number_format($nozzle->last_totalizer, 1) : $nozzle->todaySales('shift1')->first_totalizer); ?></td>
                                    <td><?php echo e($nozzle->todaySales('shift1')==null? number_format($nozzle->last_totalizer, 1) : $nozzle->todaySales('shift1')->last_totalizer); ?></td>
                                    <td><?php echo e(number_format($nozzle->salesDifference('shift1'),1)); ?></td>
                                    <td>Rp.<?php echo e(number_format($nozzle->salesDifference('shift1') * $nozzle->product->selling_price,1)); ?>,-</td>
                                    <td>
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('supply.details', $nozzle->id)); ?>">
                                                <button class="btn btn-info btn-xs mr-1">
                                                    <span class="btn-label">
                                                        <i class="fa icon-eye"></i>
                                                    </span>
                                                    Lihat
                                                </button>
                                            </a>
                                            <a href="<?php echo e(route('supply.edit', $nozzle->id)); ?>">
                                                <button class="btn btn-primary btn-xs mr-1">
                                                    <span class="btn-label">
                                                        <i class="fa icon-pencil"></i>
                                                    </span>
                                                    Edit
                                                </button>
                                            </a>
                                            <button onclick="return false" data-id="<?php echo e($nozzle->id); ?>" data-nama="<?php echo e($nozzle->id); ?>" class="confirmDelete btn btn-danger btn-xs">
                                                <span class="btn-label">
                                                    <i class="fa icon-trash"></i>
                                                </span>
                                                Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script >
    $(document).ready(function() {
        $('#basic-datatables').DataTable();
        $('#basic-datatables1').DataTable();
        $('#basic-datatables2').DataTable();

        <?php if($message = Session::get('success')): ?>
            $.notify({
                icon: 'flaticon-alarm-1',
                title: 'Sukses',
                message: '<?php echo e($message); ?>',
            },
            {
                type: 'success',
                placement: {
                    from: "top",
                    align: "center"
                },
                time: 500,
                autoHideDelay: 1000,
            });
        <?php endif; ?>
    });

    $('.confirmDelete').click(function(e) {
        let nama = e.target.dataset.nama;
        let id = e.target.dataset.id;
        let deleteURL = "<?php echo e(url('supply')); ?>"+"/"+id;
        swal({
            title: "Apakah anda yakin untuk menghapus SO "+nama+"?",
            text: "Data yang telah dihapus tidak dapat dikembalikan",
            icon: 'warning',
            buttons:{
                confirm: {
                    text : 'Ya, Hapus',
                    className : 'btn btn-success'
                },
                cancel: {
                    text : "Tidak",
                    visible: true,
                    className: 'btn btn-danger'
                }
            }
        }).then((Delete) => {
            console.log(deleteURL);
            console.log(id);
            console.log(nama);
            if (Delete) {
                $.ajax({
                type: "POST",
                url: deleteURL,
                header:{
                  'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                data: {
                    _token:'<?php echo e(csrf_token()); ?>',
                    _method: 'DELETE'
                },
                success: function (data) {
                 swal.close();
                 console.log(data);
                 $.notify({
                        icon: 'flaticon-alarm-1',
                        title: 'Sukses',
                        message: data,
                    },
                    {
                        type: 'success',
                        placement: {
                            from: "top",
                            align: "center"
                        },
                        time: 500,
                        autoHideDelay: 1000,
                 });

                 setTimeout(() => {
                    window.location.reload();
                 }, 1500);
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    console.log(XMLHttpRequest);
                    console.log(textStatus);
                    console.log(errorThrown);
                }
            });
            } else {
                swal.close();
            }
        });
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Project\Laravel\daino-tl-system\resources\views/sales/index.blade.php ENDPATH**/ ?>