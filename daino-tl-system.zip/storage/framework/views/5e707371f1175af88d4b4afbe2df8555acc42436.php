

<?php $__env->startSection('title'); ?>
    <title>Daino TL System | Pemesanan BBM</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <div class="page-header">
        <h4 class="page-title">Pemesanan BBM</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="#">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Menu Utama</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('supply.index')); ?>">Pemesanan BBM</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Tambah Pemesanan BBM</a>
            </li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Form Pemesanan BBM</h4>
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('supply-item')->html();
} elseif ($_instance->childHasBeenRendered('dKHRYzS')) {
    $componentId = $_instance->getRenderedChildComponentId('dKHRYzS');
    $componentTag = $_instance->getRenderedChildComponentTagName('dKHRYzS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dKHRYzS');
} else {
    $response = \Livewire\Livewire::mount('supply-item');
    $html = $response->html();
    $_instance->logRenderedChild('dKHRYzS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        var maskOptions = {
            lazy: true,
            signed: false,
            mask: 'Rp. num',
            mask: /^\d+$/,
            signed: false
        }
        var maskOptions2 = {
            lazy: false,
            mask: 'Rp. num',
            blocks: {
                    num: {
                    mask: Number,
                    signed: false, 
                    thousandsSeparator: '.', 
                },
            }
        }

        var so_number = document.getElementById('so_number');
        var ref_number = document.getElementById('ref_number');
        var total_amount = document.getElementById('total_amount');

        var so_number_mask = IMask(so_number, maskOptions);
        var ref_number_mask = IMask(ref_number, maskOptions);
        var total_amount_mask = IMask(total_amount, maskOptions2);
        
        function unmask(){
            $('#total_debit_amount').val(total_amount_mask.unmaskedValue);
        }

        $(document).ready(function() {

            <?php if(count($errors) > 0): ?>
                $.notify({
                icon: 'flaticon-error',
                title: 'Gagal Membuat Data',
                message: '<?php echo e($errors->first()); ?>',
                },
                {
                type: 'danger',
                placement: {
                from: "top",
                align: "center"
                },
                time: 500,
                autoHideDelay: 1000,
                });
            <?php endif; ?>
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Project\Laravel\daino-tl-system\resources\views/supply/create.blade.php ENDPATH**/ ?>