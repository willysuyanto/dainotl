<div class="card-body">
    {!! Form::model($supply, ['method' => 'PATCH','route' => ['supply.update', $supply->id], 'spellcheck' => 'false', 'autocomplete' => 'off']) !!}
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Nomor SO</strong>
            {!! Form::text('so_number', null, ['placeholder' => 'Nomor SO', 'class' => 'form-control', 'id' => 'so_number']) !!}
        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Nomor Referensi</strong>
            {!! Form::text('ref_number', null, ['placeholder' => 'Nomor Referensi', 'class' => 'form-control', 'id' => 'ref_number']) !!}
        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div wire:ignore class="form-group">
            <strong>Totalan Harga</strong>
            {!! Form::text('', null, array('placeholder' => 'Totalan Harga', 'class' => 'form-control', 'id' => 'total_amount', 'onchange' => 'unmask(value)')) !!}
            {!! Form::hidden('total_debit_amount', null, array('class' => 'form-control', 'id' => 'total_debit_amount')) !!}
        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <div class="card">
                <div class="card-header">
                    <strong>Item Pesanan BBM</strong>
                </div>
                <div class="card-body">
                    @foreach ($supplyItems as $index => $item)
                    <input type="hidden" name="supplyItems[{{$index}}][id]" wire:model="supplyItems.{{$index}}.id">
                    <div class="row justify-content-center align-items-end">
                        <div class="col-xs-12 col-sm-12 col-md-3">
                            <div class="form-group">
                                <strong>Jenis BBM</strong>
                                <div>
                                    <select name="supplyItems[{{$index}}][material]" wire:model="supplyItems.{{$index}}.material" class="form-control">
                                        <option value="">Pilih Jenis BBM</option>
                                        @foreach($allProducts as $product)
                                        <option value="{{ $product->id }}">{{ $product->product_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-3">
                            <div class="form-group">
                                <strong>Jumlah Trip</strong>
                                <div><input type="number"
                                    name="supplyItems[{{$index}}][trip]"
                                    class="form-control"
                                    wire:model="supplyItems.{{$index}}.trip" /></div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-3">
                            <div class="form-group">
                                <strong>Quantity Per Trip (L)</strong>
                                <div><input type="number"
                                    name="supplyItems[{{$index}}][trip_quantity]"
                                    class="form-control"
                                    wire:model="supplyItems.{{$index}}.trip_quantity" /></div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-2">
                            <div class="form-group">
                                <button wire:click.prevent="remove({{$index}})" class="btn btn-danger btn-block">
                                    <span class="btn-label">
                                        <i class="fa fa-times"></i>
                                    </span>
                                    Hapus
                                </button>
                            </div>
                        </div>
                    </div>                                      
                    @endforeach
                </div>
                <div class="card-footer">
                    <div class="col-xs-12 col-sm-12 col-md-2">
                        <button wire:click.prevent="add" class="btn btn-primary btn-block">
                            <span class="btn-label">
                                <i class="fa fa-plus"></i>
                            </span>
                            Tambah Item
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="card-footer row justify-content-end">
    <div class="col-xs-12 col-sm-12 col-md-2 mx-2 mb-2">
        <button type="submit" class="btn btn-primary btn-block">Simpan</button>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-2 mx-2">
        <a href="{{ URL::previous() }}" class="btn btn-danger btn-block"> Batal</a>
    </div>
</div>
{!! Form::close() !!}
