@extends('layouts.app')

@section('title')
    <title>Daino TL System | Pemesanan BBM</title>
@endsection

@section('breadcrumb')
    <div class="page-header">
        <h4 class="page-title">Pemesanan BBM</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="#">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Menu Utama</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('supply.index') }}">Pemesanan BBM</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Edit Pemesanan BBM</a>
            </li>
        </ul>
    </div>
@endsection

@section('content')
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Form Edit Pemesanan BBM</h4>
            </div>
            @livewire('edit-supply', ['supply' => $supply])
        </div>
    </div>
@endsection

@section('script')
    <script>
        var maskOptions = {
            lazy: true,
            signed: false,
            mask: 'Rp. num',
            mask: /^\d+$/,
            signed: false
        }
        var maskOptions2 = {
            lazy: true,
            mask: 'Rp. num',
            blocks: {
                    num: {
                    mask: Number,
                    signed: false, 
                    thousandsSeparator: '.', 
                },
            }
        }

        var so_number = document.getElementById('so_number');
        var ref_number = document.getElementById('ref_number');
        var total_amount = document.getElementById('total_amount');

        var so_number_mask = IMask(so_number, maskOptions);
        var ref_number_mask = IMask(ref_number, maskOptions);
        
        function unmask(){
            $('#total_debit_amount').val(total_amount_mask.unmaskedValue);
        }

        $(document).ready(function() {

            $('#total_amount').val({{$supply->total_debit_amount}});
            var total_amount_mask = IMask(total_amount, maskOptions2);

            @if (count($errors) > 0)
                $.notify({
                icon: 'flaticon-error',
                title: 'Gagal Membuat Data',
                message: '{{ $errors->first() }}',
                },
                {
                type: 'danger',
                placement: {
                from: "top",
                align: "center"
                },
                time: 500,
                autoHideDelay: 1000,
                });
            @endif
        });
    </script>
@endsection
