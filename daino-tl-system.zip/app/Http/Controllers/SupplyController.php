<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;
use App\Models\Supply;
use App\Models\SupplyItem;
use App\Models\Product;

class SupplyController extends Controller
{
    public function index()
    {
        $supplies = Supply::all();
        return view('supply.index', compact('supplies'));
    }

    public function create() 
    {
        return view('supply.create');
    }

    public function store(Request $request){

        $this->validate($request, [
            'so_number'=>'required',
            'ref_number' => 'required',
            'total_debit_amount' => 'required',
            'supplyItems.*.material' => 'required',
            'supplyItems.*.trip' => 'required',
            'supplyItems.*.trip_quantity' => 'required',
        ],
        [
            'so_number.required' => 'Kolom Nomor SO tidak boleh kosong',
            'ref_number.required' => 'Kolom Nomor Referensi tidak boleh kosong',
            'total_debit_amount.required' => 'Kolom Total Harga tidak boleh kosong',
            'supplyItems.*.material.required' => 'Kolom Item Pemesanan BBM tidak lengkap',
            'supplyItems.*.trip.required' => 'Kolom Item Pemesanan BBM tidak lengkap',
            'supplyItems.*.trip_quantity.required' => 'Kolom Item Pemesanan BBM tidak lengkap',
        ]);

        $input = $request->all();
        $input['status'] = 'Dalam Perjalanan';

        $supply = Supply::create($input);
        
        foreach ($request->supplyItems as $index => $item) {
            $product = Product::find($item['material']);
            $trip = $item['trip'];
            $trip_quantity = $item['trip_quantity'];
            $confirmed_quantity = $trip * $trip_quantity;
            $supplyItem = $supply->items()->create([ 
                'trip' => $trip, 
                'trip_quantity' => $trip_quantity, 
                'trip_delivered' => 0, 
                'confirmed_quantity' => $confirmed_quantity,
                'status' => 'Dalam Perjalanan'
            ]);
            $supplyItem->product()->attach($product);
        }

        return redirect()->route('supply.index')->with('success', 'Berhasil menyimpan data pemesanan BBM');
    }

    public function details($id){
        $supply = Supply::find($id);
        return view('supply.show', compact('supply'));
    }

    public function edit($id){
        $supply = Supply::find($id);
        return view('supply.edit', compact('supply'));
    }

    public function update(Request $request, $id){
        $this->validate($request, [
            'so_number'=>'required',
            'ref_number' => 'required',
            'total_debit_amount' => 'required',
            'supplyItems.*.material' => 'required',
            'supplyItems.*.trip' => 'required',
            'supplyItems.*.trip_quantity' => 'required',
        ],
        [
            'so_number.required' => 'Kolom Nomor SO tidak boleh kosong',
            'ref_number.required' => 'Kolom Nomor Referensi tidak boleh kosong',
            'total_debit_amount.required' => 'Kolom Total Harga tidak boleh kosong',
            'supplyItems.*.material.required' => 'Kolom Item Pemesanan BBM tidak lengkap',
            'supplyItems.*.trip.required' => 'Kolom Item Pemesanan BBM tidak lengkap',
            'supplyItems.*.trip_quantity.required' => 'Kolom Item Pemesanan BBM tidak lengkap',
        ]);
        
        $supply = Supply::find($id);
        $input = $request->all();
        $supply->update($input);

        foreach ($request->supplyItems as $index => $item) {
            $product = Product::find($item['material']);
            $trip = $item['trip'];
            $trip_quantity = $item['trip_quantity'];
            $confirmed_quantity = $trip * $trip_quantity;
            $supplyItem = $supply->items()->where('id',$item['id']);
           
            $supplyItem->update([ 
                'trip' => $trip, 
                'trip_quantity' => $trip_quantity, 
                'confirmed_quantity' => $confirmed_quantity,
            ]);

            DB::table('product_supply_item')->where('supply_item_id', $item['id'])->delete();
            $supplyItem->get()->first()->product()->attach($item['material']);
        }

        return redirect()->route('supply.index')->with('success', 'Berhasil menyimpan perubahan data pemesanan BBM'); 
    }

    public function delete($id){
       $deleted = Supply::find($id);
       //$deleted_so_number = $deleted->so_number;
       $message = "Pemesanan BBM telah dihapus";
       $deleted->delete();

       return $message;
    }

}
