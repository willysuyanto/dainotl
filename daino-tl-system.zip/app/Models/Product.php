<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'product_name',
        'purchase_price',
        'selling_price',
        'color',
    ];

    public function supplyItem(){
        return $this->belongsToMany(SupplyItem::class);
    }

    public function stocks(){
        return $this->hasMany(Stock::class);
    }

    public function nozzles(){
        return $this->hasMany(Nozzle::class);
    }

    public function getTotalQuantity(){
        
        if(count($this->stocks)>0){
            $total = 0;
            foreach ($this->stocks as $key => $value) {
                if($value->stock_type == 'stock_in' || $value->stock_type == 'initial'){
                    $total += $value->quantity;
                }else{
                    $total -= $value->quantity;
                }
            }
            return $total;
        }
        return 0;
    }
}
