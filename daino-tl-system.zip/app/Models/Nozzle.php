<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Nozzle extends Model
{
    use HasFactory;

    protected $fillable = [
        'group',
        'last_totalizer'
    ];

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function sales()
    {
        return $this->hasMany(Sales::class);
    }

    public function todaySales($shift)
    {
        return $this->sales->where('created_at', '>=', Carbon::today())->where('shift', '==', $shift)->first();
    }

    public function salesDifference($shift)
    {
        $sales = $this->sales->where('created_at', '>=', Carbon::today())->where('shift', '==', $shift)->first();
        $diff = 0;
        if($sales != null){
            $diff = $sales->last_totalizer - $sales->first_totalizer;
        }
        
        return $diff;
    }

    public function salesbyDateShift($date, $shift){
        return $this->sales->where('created_at', '>=', $date)->where('shift', '==', $shift)->first();
    }
}
